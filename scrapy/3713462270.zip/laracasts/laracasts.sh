#!/bin/bash
. /etc/profile
. ~/.bash_profile

cd /var/www/spider/laracasts
scrapy crawl laracasts